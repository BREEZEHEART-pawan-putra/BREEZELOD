package com.breeze.lod;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

@Mod(modid = BreezeLOD.MODID, name = BreezeLOD.NAME, version = BreezeLOD.VERSION, clientSideOnly = true)
public final class BreezeLOD {
    public static final String MODID = "breezelod";
    public static final String NAME = "BreezeLOD";
    public static final String VERSION = "0.1.1-alpha";

    public static volatile boolean enabled = false;
    public static int chunkRadius = 32;
    public static int sampleStep = 8;
    public static int refreshTicks = 40;

    private static KeyBinding toggleKey;
    private static File configFile;

    public static String getToggleKeyName() {
        return toggleKey == null ? "H" : Keyboard.getKeyName(toggleKey.getKeyCode());
    }


    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        configFile = new File(event.getModConfigurationDirectory(), "BreezeLOD.properties");
        loadConfig();
        toggleKey = new KeyBinding("key.breezelod.toggle", Keyboard.KEY_H, "key.categories.breezelod");
        ClientRegistry.registerKeyBinding(toggleKey);
    }


    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(new SurfaceOverlay());
        MinecraftForge.EVENT_BUS.register(this);
    }


    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (toggleKey != null && toggleKey.isPressed()) {
            enabled = !enabled;
            saveConfig();
        }
    }


    private void loadConfig() {
        Properties p = new Properties();
        if (configFile.exists()) {
            try (FileInputStream in = new FileInputStream(configFile) ) {
                p.load(in);
            } catch (IOException ignored) { }
        }
        enabled = Boolean.parseBoolean(p.getProperty("enabled", "false"));
        chunkRadius = clamp(parseInt(p, "chunkRadius", 32), 2, 32);
        sampleStep = clamp(parseInt(p, "sampleStep", 8), 2, 16);
        if (sampleStep != 2 && sampleStep != 4 && sampleStep != 8 && sampleStep != 16) sampleStep = 8;
        refreshTicks = clamp(parseInt(p, "refreshTicks", 40), 10, 200);
        saveConfig(p);
    }

    private static int parseInt(Properties p, String key, int fallback) {
        try { return Integer.parseInt(p.getProperty(key, String.valueOf(fallback)).trim()); }
        catch (RuntimeException ex) { return fallback; }
    }

    private static int clamp(int value, int min, int max) { return Math.max(min, Math.min(max, value)); }

    private void saveConfig() {
        Properties p = new Properties();
        if (configFile != null && configFile.exists()) {
            try (FileInputStream in = new FileInputStream(configFile)) { p.load(in); } catch (IOException ignored) { }
        }
        saveConfig(p);
    }

    private void saveConfig(Properties p) {
        p.setProperty("enabled", String.valueOf(enabled));
        p.setProperty("chunkRadius", String.valueOf(chunkRadius));
        p.setProperty("sampleStep", String.valueOf(sampleStep));
        p.setProperty("refreshTicks", String.valueOf(refreshTicks));
        try {
            File parent = configFile.getParentFile();
            if (parent != null) parent.mkdirs();
            try (FileOutputStream out = new FileOutputStream(configFile)) {
                p.store(out, "BreezeLOD settings. Values are clamped to safe ranges on startup.");
            }
        } catch (IOException ignored) { }
    }
}
