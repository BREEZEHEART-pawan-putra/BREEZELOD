package com.breeze.lod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.material.Material;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.event.world.ChunkEvent;
import org.lwjgl.opengl.GL11;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Lightweight, cached surface overlay prototype for Forge 1.12.2.
 * This only visualizes chunks that Minecraft has already loaded; it does not
 * create distant terrain or request additional chunks.
 */
public final class SurfaceOverlay {
    private final Minecraft mc = Minecraft.getMinecraft();
    private final Map<Long, SurfaceChunk> surfaces = new HashMap<Long, SurfaceChunk>();
    private int tickCounter;
    private int lastPlayerChunkX = Integer.MIN_VALUE;
    private int lastPlayerChunkZ = Integer.MIN_VALUE;
    private Object lastWorld;


    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || mc.player == null || mc.world == null) return;
        tickCounter++;
        if (lastWorld != mc.world) {
            surfaces.clear();
            lastWorld = mc.world;
            lastPlayerChunkX = Integer.MIN_VALUE;
            lastPlayerChunkZ = Integer.MIN_VALUE;
        }

        int pcx = mc.player.chunkCoordX;
        int pcz = mc.player.chunkCoordZ;
        boolean movedChunk = pcx != lastPlayerChunkX || pcz != lastPlayerChunkZ;
        if (movedChunk || tickCounter >= BreezeLOD.refreshTicks) {
            refreshCache(pcx, pcz);
            lastPlayerChunkX = pcx;
            lastPlayerChunkZ = pcz;
            tickCounter = 0;
        }
    }

    private void refreshCache(int centerX, int centerZ) {
        int radius = BreezeLOD.chunkRadius;
        Map<Long, Boolean> seen = new HashMap<Long, Boolean>();
        for (int cz = centerZ - radius; cz <= centerZ + radius; cz++) {
            for (int cx = centerX - radius; cx <= centerX + radius; cx++) {
                int dx = cx - centerX;
                int dz = cz - centerZ;
                if (dx * dx + dz * dz > radius * radius) continue;
                Chunk chunk = mc.world.getChunkProvider().getLoadedChunk(cx, cz);
                if (chunk == null || chunk.isEmpty()) continue;
                long key = chunkKey(cx, cz);
                seen.put(key, Boolean.TRUE);
                SurfaceChunk cached = surfaces.get(key);
                if (cached == null || cached.source != chunk || cached.step != BreezeLOD.sampleStep) {
                    surfaces.put(key, sampleChunk(chunk, cx, cz, BreezeLOD.sampleStep));
                }
            }
        }
        // Remove entries for chunks that unloaded or left the configured radius.
        Iterator<Map.Entry<Long, SurfaceChunk>> it = surfaces.entrySet().iterator();
        while (it.hasNext()) {
            if (!seen.containsKey(it.next().getKey())) it.remove();
        }
    }

    private SurfaceChunk sampleChunk(Chunk chunk, int chunkX, int chunkZ, int step) {
        int baseX = chunkX << 4;
        int baseZ = chunkZ << 4;
        int count = (16 / step) * (16 / step);
        float[] vertices = new float[count * 6]; // x, y, z, r, g, b per sample center
        int out = 0;
        for (int lx = 0; lx < 16; lx += step) {
            for (int lz = 0; lz < 16; lz += step) {
                int sx = Math.min(lx + step / 2, 15);
                int sz = Math.min(lz + step / 2, 15);
                int y = chunk.getHeight(sx, sz);
                if (y <= 0 || y >= 256) continue;
                BlockPos pos = new BlockPos(baseX + sx, y - 1, baseZ + sz);
                IBlockState state = chunk.getBlockState(pos);
                Material material = state.getMaterial();
                if (material == Material.AIR || material == Material.LAVA) continue;
                int color;
                try {
                    net.minecraft.block.material.MapColor mapColor = state.getBlock().getMapColor(state, mc.world, pos);
                    if (mapColor == null) continue;
                    color = mapColor.colorValue;
                } catch (RuntimeException ignored) {
                    // A custom block with a broken map-color implementation is skipped.
                    continue;
                }
                if (color == 0) continue;
                float r = ((color >> 16) & 255) / 255.0f;
                float g = ((color >> 8) & 255) / 255.0f;
                float b = (color & 255) / 255.0f;
                if (material == Material.WATER) { r *= 0.72f; g *= 0.78f; b *= 0.90f; }
                vertices[out++] = baseX + lx;
                vertices[out++] = y;
                vertices[out++] = baseZ + lz;
                vertices[out++] = r;
                vertices[out++] = g;
                vertices[out++] = b;
            }
        }
        return new SurfaceChunk(chunk, step, vertices, out / 6);
    }

    @SubscribeEvent
    public void onChunkUnload(ChunkEvent.Unload event) {
        if (event.getWorld() != null && event.getWorld().isRemote && event.getChunk() != null) {
            surfaces.remove(chunkKey(event.getChunk().x, event.getChunk().z));
        }
    }

    @SubscribeEvent
    public void renderStatus(RenderGameOverlayEvent.Text event) {
        if (mc.player == null || mc.gameSettings.hideGUI) return;
        String status = BreezeLOD.enabled ? "§aON" : "§7OFF";
        mc.fontRenderer.drawStringWithShadow("BreezeLOD " + status + " §7[" + BreezeLOD.getToggleKeyName() + "]", 6, 6, 0xFFFFFF);
    }

    @SubscribeEvent
    public void render(RenderWorldLastEvent event) {
        if (!BreezeLOD.enabled || mc.player == null || mc.world == null || mc.gameSettings.hideGUI) return;
        double viewerX = mc.getRenderManager().viewerPosX;
        double viewerY = mc.getRenderManager().viewerPosY;
        double viewerZ = mc.getRenderManager().viewerPosZ;
        int pcx = mc.player.chunkCoordX;
        int pcz = mc.player.chunkCoordZ;
        int radiusSq = BreezeLOD.chunkRadius * BreezeLOD.chunkRadius;

        GlStateSnapshot state = GlStateSnapshot.capture();
        try {
            GL11.glPushMatrix();
            try {
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glEnable(GL11.GL_BLEND);
            GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            GL11.glEnable(GL11.GL_DEPTH_TEST);
            GL11.glDepthMask(false);
            GL11.glDisable(GL11.GL_CULL_FACE);

            Tessellator tess = Tessellator.getInstance();
            BufferBuilder buf = tess.getBuffer();
            buf.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
            for (SurfaceChunk data : surfaces.values()) {
                int dx = data.source.x - pcx;
                int dz = data.source.z - pcz;
                if (dx * dx + dz * dz > radiusSq || dx * dx + dz * dz <= 9) continue;
                drawChunk(buf, data, viewerX, viewerY, viewerZ);
            }
            tess.draw();
            } finally {
                GL11.glPopMatrix();
            }
        } finally {
            state.restore();
        }
    }


    private void drawChunk(BufferBuilder buf, SurfaceChunk data, double vx, double vy, double vz) {
        int step = data.step;
        for (int i = 0; i < data.sampleCount; i++) {
            int p = i * 6;
            double x = data.vertices[p] - vx;
            double y = data.vertices[p + 1] - vy + 0.025;
            double z = data.vertices[p + 2] - vz;
            float r = data.vertices[p + 3];
            float g = data.vertices[p + 4];
            float b = data.vertices[p + 5];
            float a = 0.48f;
            buf.pos(x, y, z).color(r, g, b, a).endVertex();
            buf.pos(x + step, y, z).color(r, g, b, a).endVertex();
            buf.pos(x + step, y, z + step).color(r, g, b, a).endVertex();
            buf.pos(x, y, z + step).color(r, g, b, a).endVertex();
        }
    }

    private static long chunkKey(int x, int z) {
        return (((long) x) << 32) ^ (z & 0xffffffffL);
    }


    private static final class SurfaceChunk {
        final Chunk source;
        final int step;
        final float[] vertices;
        final int sampleCount;
        SurfaceChunk(Chunk source, int step, float[] vertices, int sampleCount) {
            this.source = source;
            this.step = step;
            this.vertices = vertices;
            this.sampleCount = sampleCount;
        }
    }


    /** Save and restore the common GL state modified by this overlay. */
    private static final class GlStateSnapshot {
        final boolean texture, blend, depth, cull;
        final boolean depthMask;
        final int blendSrc, blendDst;
        private GlStateSnapshot() {
            texture = GL11.glIsEnabled(GL11.GL_TEXTURE_2D);
            blend = GL11.glIsEnabled(GL11.GL_BLEND);
            depth = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
            cull = GL11.glIsEnabled(GL11.GL_CULL_FACE);
            depthMask = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
            blendSrc = GL11.glGetInteger(GL11.GL_BLEND_SRC);
            blendDst = GL11.glGetInteger(GL11.GL_BLEND_DST);
        }
        static GlStateSnapshot capture() { return new GlStateSnapshot(); }
        void restore() {
            if (texture) GL11.glEnable(GL11.GL_TEXTURE_2D); else GL11.glDisable(GL11.GL_TEXTURE_2D);
            if (blend) GL11.glEnable(GL11.GL_BLEND); else GL11.glDisable(GL11.GL_BLEND);
            if (depth) GL11.glEnable(GL11.GL_DEPTH_TEST); else GL11.glDisable(GL11.GL_DEPTH_TEST);
            if (cull) GL11.glEnable(GL11.GL_CULL_FACE); else GL11.glDisable(GL11.GL_CULL_FACE);
            GL11.glDepthMask(depthMask);
            GL11.glBlendFunc(blendSrc, blendDst);
        }
    }
}
